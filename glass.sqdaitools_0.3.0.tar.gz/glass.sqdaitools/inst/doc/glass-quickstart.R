## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(glass.sqdaitools)

## -----------------------------------------------------------------------------
glass_registry(verified_only = TRUE)[, c("variant_id", "res", "cadence_days",
                                         "observed_years", "url_root")]

## -----------------------------------------------------------------------------
# 一个 2-3 km 缓冲的点(上海人民广场周边)
roi <- sf::st_buffer(
  sf::st_sfc(sf::st_point(c(121.47, 31.23)), crs = 4326),
  3000
)
tiles <- glass_tiles_for_sf(roi)
tiles[, c("h", "v", "lon_min", "lon_max", "lat_min", "lat_max", "valid")]

## -----------------------------------------------------------------------------
glass_doys("LAI_MODIS_250M", from = "2018-08-01", to = "2018-08-31")

## ----eval=FALSE---------------------------------------------------------------
# files <- glass_fetch(
#   "LAI_MODIS_250M",
#   from = "2018-08-01", to = "2018-12-31",
#   roi = roi,
#   out_dir = "data/glass/lai"
# )
# # 用 dry_run = TRUE 先看清单,不下载

## ----eval=FALSE---------------------------------------------------------------
# mean_lai <- glass_process(
#   files,
#   roi = roi,
#   product = "LAI_MODIS_250M",
#   method = "cubic",
#   fun = "mean",
#   outfile = "glass_lai_mean.tif"
# )

## ----eval=FALSE---------------------------------------------------------------
# glass_app()

