# Manuscript outline — Environmental Modelling & Software

**Working title**
`glass.sqdaitools`: an R toolkit for the lifecycle of GLASS land surface
satellite products — registry, tiled retrieval, resumable download and
post-processing

**Target journal**: Environmental Modelling & Software (Elsevier)
**Length target**: 7,000–9,000 words; 5–7 figures; 2–3 tables
**Software paper type**: EMS 要求文末含 **Software availability** 节(见 §8 模板)

> 中文注:以下每节标题用英文(投稿即用),括号内为写作要点与素材来源。
> 所有代码示例必须与 vignette/README 保持一致,跑得通。

---

## Highlights(3–5 条,每条 ≤85 字符)

- An R toolkit covering the full GLASS product lifecycle, from archive to analysis-ready rasters.
- A curated registry encodes heterogeneous archive layouts and verified band metadata.
- Resumable, size-verified batch downloads over the public GLASS directory listing.
- Exact sinusoidal tile mapping links any ROI to the h/v granules it needs.
- Interactive Leaflet UI and terra post-processing chain, validated on a Shanghai case study.

## Keywords

GLASS; land surface products; R package; satellite data retrieval;
MODIS sinusoidal tiling; reproducible research

---

## 1. Introduction

- 长时序地表卫星产品的数据获取摩擦:GLASS(28 个产品目录)归档结构异构
  (层级/分辨率命名/合成节奏不一)、分幅命名、填充值与比例因子不统一。
- 现有生态:MODIS 有 `MODIS`/`MODISTools`、Sentinel 有 `sen2r`、GEE 可在线处理;
  **GLASS 至今无专用 R 工具**(引言的核心 gap)。
- 三条贡献:
  1) 产品登记表(registry)以数据驱动方式编码归档结构与波段元数据;
  2) 覆盖 查-定-换-下-读-出 全生命周期的最小 API(13 个导出函数);
  3) 断点续传/校验的下载引擎 + 交互式 Leaflet 界面 + D3L Tool 桌面软件联动。
- 素材:交付记录中的生态空位论证;archive 扫描发现的 4 类布局差异。

## 2. Related work

- MODIS/R 生态对比表:`MODIS`、`MODISTools`、`rsat`(多传感器)、`sen2r`;
  GEE/AppEEARS 等在线平台(需要账号/在线算力 vs 本地批量)。
- 对比维度:目标数据集、断点续传、元数据驱动、离线可用、GUI。
- 结论句式:没有一个同时满足"GLASS 专属 + 登记表驱动 + 本地断点下载 + R 后处理"。

## 3. Software overview and architecture

- **Fig. 1 架构图**(六模块流水线):
  Registry → Tiles(正弦投影精确多边形)→ DOY(span/start 双语义)→
  List(autoindex 解析)→ Download(httr2 引擎:HEAD 校验/Range 续传/重试/
  manifest 台账)→ Read & Process(terra:填值/镶嵌/重投影/时间合成)。
- 设计原则三条:
  1) **元数据驱动**:路径模板、命名片段、fill/scale 全在登记表,不在代码;
  2) **薄 UI**:Shiny/Leaflet 界面只做编排,核心逻辑全在可脚本化函数;
  3) **可中断**:下载原子化(.part + rename),台账 CSV 支撑跨会话幂等。
- Table 1:登记表字段全表(21 列,分组:标识/布局/命名/波段元数据/状态)。

## 4. Key capabilities and implementation

### 4.1 Registry:from archive scan to verified metadata
- 构建链:crawl → probe → verify(实测样例 HDF 的 band 元数据)。
- 核验结论表:GLASS01D01 V6 scale=0.1/fill=255/valid[0,10];
  GLASS13D01/GLASS14D01 V1 scale=0.01/valid[-0.2,1]/[-0.1,1]
  (来源:data-raw/band_meta.csv)。

### 4.2 ROI → sinusoidal tiles
- 精确重建 tile 多边形公式:x=(h−18)t, y=(9−v)t,t=1111950.52 m;
  st_intersects;与内置 glass_tiles 查找表互验(单元测试断言 <0.08°)。

### 4.3 Date range → composite DOY folders
- span vs start 语义;跨年文件夹归属(起始年);与旧脚本枚举 217–361 对拍一致。

### 4.4 Resumable download engine
- 状态机:skip(HEAD Content-Length 比对)→ resume(Range + .part 追加)→
  fresh(.part 先行 + 原子 rename);req_retry 指数退避;
  glass_manifest.csv 台账;实测:4 granule/28 s,重跑 4/4 skipped。

### 4.5 Post-processing
- glass_read(登记表驱动的 fill→NA、有效范围裁剪)、glass_mosaic(merge)、
  glass_process(分组按日期 → 逐日镶嵌 → 重投影 → crop/mask → fun 折叠)。
- 注意:terra/GDAL 已自动套用 SDS scale/offset 的实现细节(审稿人常问)。

## 5. Case study: warm-season vegetation over Shanghai, 2018

- 工作流:上海边界 → h28v05 → LAI/NDVI/EVI 2018-08..12 → 下载 →
  UTM51N cubic 250 m → 季均 → GeoTIFF。
- **Fig. 2** ROI-瓦片映射图;**Fig. 3** 三产品季均图(ggplot/tidyterra);
  **Fig. 4** 下载性能与幂等性(柱状:首次 downloaded vs 重跑 skipped)。
- 验证性数值:上海点 NDVI=0.4335、LAI=0.8(2018-DOY217),与物理预期一致;
  水体 fill=2.55→NA 正确剔除。
- 运行环境表(Windows 11 / R 4.6.1 / terra 1.9.27 / httr2 x)。

## 6. Discussion

- 局限:133 变体中 5 个已核验(扩充路径已给);HDF4 依赖 GDAL 驱动;
  目录解析依赖 autoindex 格式稳定;礼貌延迟限制并发。
- 可扩展性:登记表如何覆盖其余产品;多传感器推广(仅换登记表)。
- GUI 联动:D3L Tool v2.5.0 集成下载骨架,后处理仍依赖本包
  (软件协同的案例,呼应 EMS 对软件生态的兴趣)。

## 7. Conclusions and future work

- 未来:登记表批量核验、glass_sync 差量同步、有限并发、代理支持、
  更多云归档适配。

## 8. Software availability(EMS 固定栏目,直接套模板)

- **Name of software**: glass.sqdaitools
- **Developer**: Shaoqing Dai (ORCID: 0000-0003-0858-4728;
  contact: dsq1993qingge@163.com; homepage: https://gisersqdai.top/mycv/)
- **Year first available**: 2026
- **Program language**: R (≥ 4.1); dependencies: httr2, terra, sf, rvest, tibble
- **Software required**: Windows/macOS/Linux; GDAL with HDF4 support (via terra)
- **Availability**: https://github.com/GISerDaiShaoqing/glass.sqdaitools
  (source, MIT); docs: https://giserdaishaoqing.github.io/glass.sqdaitools/
- **Cost**: free, open source (MIT)

## 9. Declarations

- CRediT author contributions; Code availability(同 §8);
  Data availability(GLASS 公开归档,glass.hku.hk;案例输出随仓库 release);
- 致谢 GLASS 产品团队;声明无利益冲突。

---

## 写作排期建议

1. 先写 §3–§4(素材最全,基本是 README/vignette 改写);
2. 跑齐案例数据出 Fig.2–4(可复用 smoke_test 的产物);
3. 再回补 §1–§2(引言的 gap 论证需要文献功课:MODIS/rsat/sen2r/GEE 各 3–5 篇);
4. §8 套模板 10 分钟;全文成稿后请同行预审一遍 R CMD check 式的"代码可复跑"审查。
