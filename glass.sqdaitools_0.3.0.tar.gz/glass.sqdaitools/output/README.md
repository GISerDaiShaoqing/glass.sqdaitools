# output/ — 本地写作与申报工作区(不上 GitHub)

本目录被 `.gitignore` 排除,**任何内容不得提交、推送或发布**。
存放与包相关的论文手稿、期刊大纲、软件著作权申报等本地材料。

## 目录

```
output/
├── paper/
│   └── EMS_manuscript_outline.md   # Environmental Modelling & Software 投稿骨架
└── copyright/
    └── software_copyright_checklist.md   # 软著申请材料清单与大纲
```

## 使用约定

- 论文正文建议在 `paper/` 下另建 `manuscript.md` / `.docx` 逐步成稿;
  图表放 `paper/figures/`,投稿用数据放 `paper/data/`。
- 手稿与材料中**不得出现私人文件夹路径**(与 AGENTS.md 规则一致)——
  软著源码材料打印前尤其要检查。
- 与包功能对应的所有代码示例直接从 README/vignette 摘取,保证
  "论文所述 = 软件所为"。
